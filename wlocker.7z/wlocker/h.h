bool InstallDriverWithSCManager();
bool StopDriver();
void WriteToPort(USHORT PortAdr, USHORT PortValue);
USHORT ReadFromPort(USHORT PortAdr);